function greeter(person) {
    return "Hello, " + person;
}
console.log(greeter('TypeScript'));
