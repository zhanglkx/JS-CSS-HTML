function greeter(person: string) {
    return "Hello, " + person;
}

console.log(greeter('TypeScript'));
